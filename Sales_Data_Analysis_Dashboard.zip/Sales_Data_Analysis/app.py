"""Interactive sales dashboard for the sample retail dataset."""

from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from sales_analysis import enrich_sales_data, load_and_clean_data

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "sales_data.csv"
PALETTE = {
    "background": "#061321",
    "panel": "#0b1c30",
    "panel_alt": "#102741",
    "text": "#edf4ff",
    "muted": "#9aafc7",
    "blue": "#2878f0",
    "purple": "#b044e8",
    "green": "#18c995",
    "orange": "#ff9f24",
    "red": "#f24b70",
}

st.set_page_config(
    page_title="Sales Workspace | Performance Dashboard",
    page_icon="📊",
    layout="wide",
)

st.markdown(
    f"""
    <style>
        .stApp {{
            background:
                radial-gradient(ellipse at 70% -20%, #102b4b 0%, transparent 55%),
                {PALETTE["background"]};
            color: {PALETTE["text"]};
        }}
        [data-testid="stSidebar"] {{
            background: #08182a;
            border-right: 1px solid #18304b;
        }}
        [data-testid="stSidebar"] h1 {{
            font-size: 1.35rem;
            color: #f4f8ff;
        }}
        [data-testid="stMetric"] {{
            background: linear-gradient(135deg, #102944, #0b1c30);
            border: 1px solid #1b3654;
            border-radius: 14px;
            padding: 18px 20px;
            min-height: 112px;
        }}
        [data-testid="stMetricLabel"] p {{
            color: {PALETTE["muted"]};
        }}
        [data-testid="stMetricValue"] {{
            color: {PALETTE["text"]};
        }}
        div[data-testid="stPlotlyChart"] {{
            background: {PALETTE["panel"]};
            border: 1px solid #18304b;
            border-radius: 14px;
            padding: 8px;
        }}
        .dashboard-subtitle {{
            color: {PALETTE["muted"]};
            margin: 0.25rem 0 1.2rem;
        }}
        .dashboard-header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            margin: 0.5rem 0 1.25rem;
        }}
        .dashboard-title {{
            color: {PALETTE["text"]};
            font-size: 2rem;
            font-weight: 750;
            line-height: 1.15;
        }}
        .period-chip {{
            flex: 0 0 auto;
            color: #c6d7eb;
            background: #102741;
            border: 1px solid #1e3b5b;
            border-radius: 9px;
            padding: 9px 12px;
            font-size: 0.85rem;
        }}
        @media (max-width: 750px) {{
            .dashboard-header {{
                align-items: flex-start;
                flex-direction: column;
            }}
        }}
        .section-note {{
            color: {PALETTE["muted"]};
            font-size: 0.88rem;
        }}
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_data
def load_sales_data() -> pd.DataFrame:
    """Load, clean, and enrich the CSV once per app session."""
    return enrich_sales_data(load_and_clean_data(DATA_FILE))


def format_inr(amount: float) -> str:
    return f"INR {amount:,.2f}"


def style_chart(fig: go.Figure, *, height: int = 320) -> go.Figure:
    fig.update_layout(
        height=height,
        paper_bgcolor=PALETTE["panel"],
        plot_bgcolor=PALETTE["panel"],
        font={"color": PALETTE["text"], "family": "Arial"},
        margin={"l": 18, "r": 18, "t": 48, "b": 18},
        legend={
            "orientation": "h",
            "yanchor": "bottom",
            "y": 1.02,
            "x": 0,
            "font": {"color": PALETTE["muted"]},
        },
        xaxis={
            "gridcolor": "#18314b",
            "zerolinecolor": "#18314b",
            "linecolor": "#18314b",
        },
        yaxis={
            "gridcolor": "#18314b",
            "zerolinecolor": "#18314b",
            "linecolor": "#18314b",
        },
        title={"font": {"size": 16, "color": PALETTE["text"]}},
    )
    return fig


try:
    sales = load_sales_data()
except (FileNotFoundError, ValueError, pd.errors.ParserError) as error:
    st.error(f"Unable to load the sales dataset: {error}")
    st.stop()

st.sidebar.markdown("## 📊 Sales Workspace")
st.sidebar.caption("Retail performance overview")
st.sidebar.divider()
page = st.sidebar.radio(
    "Workspace",
    ["Dashboard", "Sales Analysis", "Product Performance", "Trends"],
    label_visibility="collapsed",
)
st.sidebar.divider()
st.sidebar.subheader("Dashboard Filters")

date_bounds = (sales["OrderDate"].min().date(), sales["OrderDate"].max().date())
selected_dates = st.sidebar.date_input(
    "Order date range",
    value=date_bounds,
    min_value=date_bounds[0],
    max_value=date_bounds[1],
)
selected_regions = st.sidebar.pills(
    "Region",
    options=sorted(sales["Region"].unique()),
    selection_mode="multi",
    default=sorted(sales["Region"].unique()),
)
selected_categories = st.sidebar.pills(
    "Category",
    options=sorted(sales["Category"].unique()),
    selection_mode="multi",
    default=sorted(sales["Category"].unique()),
)
st.sidebar.markdown("---")
st.sidebar.caption("Better data. Smarter decisions.")

if len(selected_dates) != 2:
    st.sidebar.info("Select both a start and end date to view results.")
    st.stop()

start_date, end_date = selected_dates
filtered = sales.loc[
    sales["OrderDate"].dt.date.between(start_date, end_date)
    & sales["Region"].isin(selected_regions)
    & sales["Category"].isin(selected_categories)
].copy()

st.markdown(
    f'<div class="dashboard-header"><div><div class="dashboard-title">'
    f"Sales Performance Dashboard</div><div class='dashboard-subtitle'>"
    "Explore revenue, sales volume, and product mix for the included sample dataset."
    f"</div></div><div class='period-chip'>Reporting period<br>"
    f"<b>{start_date:%b %d, %Y} &nbsp;→&nbsp; {end_date:%b %d, %Y}</b>"
    "</div></div>",
    unsafe_allow_html=True,
)

if filtered.empty:
    st.warning("No sales match the selected filters. Adjust the date range or filters.")
    st.stop()

total_revenue = filtered["Revenue"].sum()
sales_records = len(filtered)
units_sold = filtered["Quantity"].sum()
average_record_value = total_revenue / sales_records if sales_records else 0

kpis = st.columns(4)
kpis[0].metric("Total Revenue", format_inr(total_revenue))
kpis[1].metric("Sales Records", f"{sales_records:,}")
kpis[2].metric("Units Sold", f"{units_sold:,.0f}")
kpis[3].metric("Avg. Revenue / Record", format_inr(average_record_value))

monthly = (
    filtered.assign(
        MonthStart=filtered["OrderDate"].dt.to_period("M").dt.to_timestamp()
    )
    .groupby("MonthStart", as_index=False)
    .agg(Revenue=("Revenue", "sum"), Records=("Product", "size"))
)
products = (
    filtered.groupby(["Product", "Category"], as_index=False)
    .agg(
        Revenue=("Revenue", "sum"),
        UnitsSold=("Quantity", "sum"),
        Records=("Product", "size"),
    )
    .sort_values("Revenue", ascending=False)
)
regions = (
    filtered.groupby("Region", as_index=False)
    .agg(Revenue=("Revenue", "sum"), Records=("Product", "size"))
    .sort_values("Revenue", ascending=False)
)
categories = (
    filtered.groupby("Category", as_index=False)["Revenue"]
    .sum()
    .sort_values("Revenue", ascending=False)
)

if page == "Dashboard":
    trend_col, category_col = st.columns([1.42, 1])
    with trend_col:
        st.subheader("Revenue Trend")
        trend_fig = go.Figure()
        trend_fig.add_trace(
            go.Bar(
                x=monthly["MonthStart"],
                y=monthly["Revenue"],
                name="Revenue",
                marker_color=PALETTE["blue"],
                opacity=0.94,
            )
        )
        trend_fig.add_trace(
            go.Scatter(
                x=monthly["MonthStart"],
                y=monthly["Records"],
                name="Sales records",
                mode="lines+markers",
                yaxis="y2",
                line={"color": PALETTE["purple"], "width": 3},
                marker={"size": 6},
            )
        )
        trend_fig.update_layout(
            xaxis_title=None,
            yaxis_title="Revenue (INR)",
            yaxis2={
                "title": "Sales records",
                "overlaying": "y",
                "side": "right",
                "showgrid": False,
                "color": PALETTE["muted"],
            },
            barmode="group",
        )
        st.plotly_chart(style_chart(trend_fig, height=330), use_container_width=True)

    with category_col:
        st.subheader("Sales by Category")
        category_fig = px.pie(
            categories,
            names="Category",
            values="Revenue",
            hole=0.68,
            color="Category",
            color_discrete_sequence=[PALETTE["blue"], PALETTE["purple"], PALETTE["green"]],
        )
        category_fig.update_traces(
            textposition="inside",
            textinfo="percent",
            marker={"line": {"color": PALETTE["panel"], "width": 3}},
            hovertemplate="%{label}<br>Revenue: INR %{value:,.2f}<extra></extra>",
        )
        category_fig.add_annotation(
            text=f"<b>{format_inr(total_revenue)}</b><br><span style='font-size:11px'>Total Revenue</span>",
            x=0.5,
            y=0.5,
            showarrow=False,
            font={"color": PALETTE["text"], "size": 15},
        )
        category_fig.update_layout(showlegend=True)
        st.plotly_chart(style_chart(category_fig, height=330), use_container_width=True)

    product_col, region_col = st.columns([1.2, 1])
    with product_col:
        st.subheader("Top 5 Products by Revenue")
        top_products = products.head(5).copy()
        top_products.insert(0, "Rank", range(1, len(top_products) + 1))
        top_products["Revenue"] = top_products["Revenue"].map(format_inr)
        st.dataframe(
            top_products[["Rank", "Product", "Category", "Revenue", "Records"]],
            use_container_width=True,
            hide_index=True,
            height=255,
        )

    with region_col:
        st.subheader("Regional Sales Comparison")
        region_fig = px.bar(
            regions.sort_values("Revenue"),
            x="Revenue",
            y="Region",
            orientation="h",
            color="Region",
            color_discrete_sequence=[
                PALETTE["blue"],
                PALETTE["purple"],
                PALETTE["green"],
                PALETTE["orange"],
            ],
            labels={"Revenue": "Revenue (INR)", "Region": ""},
        )
        region_fig.update_layout(showlegend=False)
        region_fig.update_traces(
            texttemplate="INR %{x:,.0f}",
            textposition="outside",
            cliponaxis=False,
        )
        st.plotly_chart(style_chart(region_fig, height=255), use_container_width=True)

elif page == "Sales Analysis":
    st.subheader("Sales Analysis")
    left, right = st.columns(2)
    with left:
        region_fig = px.bar(
            regions.sort_values("Revenue"),
            x="Revenue",
            y="Region",
            orientation="h",
            color="Revenue",
            color_continuous_scale=[PALETTE["blue"], PALETTE["purple"]],
            title="Revenue by Region",
            labels={"Revenue": "Revenue (INR)", "Region": ""},
        )
        st.plotly_chart(style_chart(region_fig), use_container_width=True)
    with right:
        discount_summary = pd.DataFrame(
            {
                "Sales": ["Gross sales", "Discounts", "Net revenue"],
                "Amount": [
                    filtered["GrossSales"].sum(),
                    filtered["DiscountAmount"].sum(),
                    total_revenue,
                ],
            }
        )
        discount_fig = px.bar(
            discount_summary,
            x="Sales",
            y="Amount",
            color="Sales",
            title="Discount Impact",
            color_discrete_sequence=[PALETTE["blue"], PALETTE["purple"], PALETTE["green"]],
            labels={"Amount": "Amount (INR)", "Sales": ""},
        )
        discount_fig.update_layout(showlegend=False)
        st.plotly_chart(style_chart(discount_fig), use_container_width=True)

    st.subheader("Category Revenue Mix")
    st.dataframe(categories, use_container_width=True, hide_index=True)

elif page == "Product Performance":
    st.subheader("Product Performance")
    product_fig = px.bar(
        products.sort_values("Revenue"),
        x="Revenue",
        y="Product",
        orientation="h",
        color="Revenue",
        color_continuous_scale=[PALETTE["blue"], PALETTE["purple"]],
        labels={"Revenue": "Revenue (INR)", "Product": ""},
    )
    st.plotly_chart(style_chart(product_fig, height=380), use_container_width=True)
    st.dataframe(products, use_container_width=True, hide_index=True)

else:
    st.subheader("Trends")
    st.markdown(
        '<p class="section-note">Monthly results for the selected date range. '
        "The dataset contains one year of sample records, so no forecast is shown.</p>",
        unsafe_allow_html=True,
    )
    monthly_table = monthly.copy()
    monthly_table["MonthStart"] = monthly_table["MonthStart"].dt.strftime("%b %Y")
    monthly_table["Revenue"] = monthly_table["Revenue"].map(format_inr)
    st.dataframe(monthly_table, use_container_width=True, hide_index=True)

st.divider()
st.subheader("Sales Records")
display_columns = [
    "OrderDate",
    "Region",
    "Product",
    "Category",
    "Quantity",
    "UnitPrice",
    "Discount",
    "Revenue",
]
st.dataframe(
    filtered[display_columns].sort_values("OrderDate", ascending=False),
    use_container_width=True,
    hide_index=True,
)
st.download_button(
    "Download filtered sales as CSV",
    data=filtered[display_columns].to_csv(index=False).encode("utf-8"),
    file_name="sales_data_filtered.csv",
    mime="text/csv",
)
st.caption(
    "Synthetic sample data for learning and demonstration. Revenue is gross sales "
    "less the per-unit discount; each row represents a sales record."
)
